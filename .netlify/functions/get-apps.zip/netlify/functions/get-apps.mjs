
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/get-apps.ts
import { neon } from "@neondatabase/serverless";
var get_apps_default = async (req, context) => {
  if (req.method !== "GET") {
    return new Response("Method Not Allowed", { status: 405 });
  }
  try {
    const sql = neon(process.env.DATABASE_URL);
    const apps = await sql`SELECT * FROM apps ORDER BY created_at DESC`;
    return new Response(JSON.stringify(apps), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("Error fetching apps:", error);
    return new Response(JSON.stringify({ error: "Internal Server Error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
export {
  get_apps_default as default
};
